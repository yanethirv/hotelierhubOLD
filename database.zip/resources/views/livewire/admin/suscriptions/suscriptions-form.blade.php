<div class="row">
    <div class="col-lg-7 mx-auto">
        <div class="bg-white rounded-lg shadow-sm p-5">
            <h3 class="mb-4 text-center">
              @if($selected_id == 0) {{ __("Create Subscription") }}
              @else {{ __("Edit Subscription") }}
              @endif
            </h3>

          </div>
        </div>
    </div>
  </div>
  