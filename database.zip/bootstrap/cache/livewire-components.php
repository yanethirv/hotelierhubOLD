<?php return array (
  'admin.activations-request-component' => 'App\\Http\\Livewire\\Admin\\ActivationsRequestComponent',
  'admin.permissions-component' => 'App\\Http\\Livewire\\Admin\\PermissionsComponent',
  'admin.products-component' => 'App\\Http\\Livewire\\Admin\\ProductsComponent',
  'admin.products-request-component' => 'App\\Http\\Livewire\\Admin\\ProductsRequestComponent',
  'admin.roles-component' => 'App\\Http\\Livewire\\Admin\\RolesComponent',
  'admin.subscriptions-request-component' => 'App\\Http\\Livewire\\Admin\\SubscriptionsRequestComponent',
  'admin.suscriptions-component' => 'App\\Http\\Livewire\\Admin\\SuscriptionsComponent',
  'admin.types-component' => 'App\\Http\\Livewire\\Admin\\TypesComponent',
  'admin.users-component' => 'App\\Http\\Livewire\\Admin\\UsersComponent',
);